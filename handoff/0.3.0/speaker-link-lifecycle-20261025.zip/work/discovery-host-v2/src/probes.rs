use speakerlink_core::ErrorCode;
use speakerlink_windows::DiscoveryOutcome;
use std::future::Future;
use std::sync::Arc;
use std::task::{Context, Poll, Wake, Waker};
use std::time::{Duration, Instant};

type DiscoveryResult = Result<DiscoveryOutcome, ErrorCode>;
const TICK: Duration = Duration::from_millis(10);

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum ProbeKind {
    DropAfterPending,
    ShortDeadline,
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum FirstPoll {
    Pending,
    Ready,
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum PublicOutcome {
    Services(usize),
    Cancelled,
    Error(ErrorCode),
    NoReadyResult,
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Stimulus {
    ActualOwnerDropped,
    ContinuedPolling,
    NotApplied,
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum HarnessResult {
    Completed,
    HostWaitBudgetExceeded,
}
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Recovery {
    NotRun,
    Observed {
        outcome: PublicOutcome,
        harness: HarnessResult,
    },
}

#[derive(Clone, Copy)]
pub enum NativeCleanup {
    NotObservable,
}

pub struct ProbeReport {
    pub kind: ProbeKind,
    pub first_poll: FirstPoll,
    pub public_outcome: PublicOutcome,
    pub stimulus: Stimulus,
    pub harness: HarnessResult,
    pub pending_path_covered: bool,
    pub recovery: Recovery,
    pub native_cleanup: NativeCleanup,
}

impl PublicOutcome {
    fn from_result(result: DiscoveryResult) -> Self {
        match result {
            Ok(DiscoveryOutcome::Services(services)) => Self::Services(services.len()),
            Ok(DiscoveryOutcome::Cancelled) => Self::Cancelled,
            Err(code) => Self::Error(code),
        }
    }

    fn text(self) -> String {
        match self {
            Self::Services(count) => format!("Services count={count}"),
            Self::Cancelled => "Cancelled".into(),
            Self::Error(code) => format!("Error code={}", code.as_str()),
            Self::NoReadyResult => "NoReadyResult".into(),
        }
    }

    pub fn must_stop(self) -> bool {
        matches!(
            self,
            Self::Error(ErrorCode::AccessDenied | ErrorCode::Disconnected)
        )
    }
}

struct ThreadWake(std::thread::Thread);
impl Wake for ThreadWake {
    fn wake(self: Arc<Self>) {
        self.0.unpark();
    }
    fn wake_by_ref(self: &Arc<Self>) {
        self.0.unpark();
    }
}

fn drive<F: Future<Output = DiscoveryResult>>(
    future: F,
    drop_pending: bool,
    budget: Duration,
) -> (FirstPoll, PublicOutcome, Stimulus, HarnessResult) {
    let deadline = Instant::now() + budget;
    let waker = Waker::from(Arc::new(ThreadWake(std::thread::current())));
    let mut context = Context::from_waker(&waker);
    let observed = {
        let mut owner = Box::pin(future);
        let first = owner.as_mut().poll(&mut context);
        let first_poll = if first.is_pending() {
            FirstPoll::Pending
        } else {
            FirstPoll::Ready
        };
        if Instant::now() >= deadline {
            let outcome = match first {
                Poll::Ready(value) => PublicOutcome::from_result(value),
                Poll::Pending => PublicOutcome::NoReadyResult,
            };
            (
                first_poll,
                outcome,
                Stimulus::NotApplied,
                HarnessResult::HostWaitBudgetExceeded,
            )
        } else if let Poll::Ready(value) = first {
            (
                first_poll,
                PublicOutcome::from_result(value),
                Stimulus::NotApplied,
                HarnessResult::Completed,
            )
        } else if drop_pending {
            drop(owner);
            let harness = if Instant::now() >= deadline {
                HarnessResult::HostWaitBudgetExceeded
            } else {
                HarnessResult::Completed
            };
            return (
                first_poll,
                PublicOutcome::NoReadyResult,
                Stimulus::ActualOwnerDropped,
                harness,
            );
        } else {
            loop {
                std::thread::park_timeout(
                    TICK.min(deadline.saturating_duration_since(Instant::now())),
                );
                if Instant::now() >= deadline {
                    break (
                        first_poll,
                        PublicOutcome::NoReadyResult,
                        Stimulus::ContinuedPolling,
                        HarnessResult::HostWaitBudgetExceeded,
                    );
                }
                let result = owner.as_mut().poll(&mut context);
                let guard_expired = Instant::now() >= deadline;
                if let Poll::Ready(value) = result {
                    let harness = if guard_expired {
                        HarnessResult::HostWaitBudgetExceeded
                    } else {
                        HarnessResult::Completed
                    };
                    break (
                        first_poll,
                        PublicOutcome::from_result(value),
                        Stimulus::ContinuedPolling,
                        harness,
                    );
                }
                if guard_expired {
                    break (
                        first_poll,
                        PublicOutcome::NoReadyResult,
                        Stimulus::ContinuedPolling,
                        HarnessResult::HostWaitBudgetExceeded,
                    );
                }
            }
        }
    };
    // The owning Future has been destroyed before its observation can reach recovery.
    if Instant::now() >= deadline {
        (
            observed.0,
            observed.1,
            observed.2,
            HarnessResult::HostWaitBudgetExceeded,
        )
    } else {
        observed
    }
}

pub fn probe<F: Future<Output = DiscoveryResult>>(
    kind: ProbeKind,
    future: F,
    budget: Duration,
) -> ProbeReport {
    let (first_poll, public_outcome, stimulus, harness) =
        drive(future, kind == ProbeKind::DropAfterPending, budget);
    let pending_path_covered = harness == HarnessResult::Completed
        && first_poll == FirstPoll::Pending
        && match kind {
            ProbeKind::DropAfterPending => stimulus == Stimulus::ActualOwnerDropped,
            ProbeKind::ShortDeadline => public_outcome == PublicOutcome::Error(ErrorCode::Timeout),
        };
    ProbeReport {
        kind,
        first_poll,
        public_outcome,
        stimulus,
        harness,
        pending_path_covered,
        recovery: Recovery::NotRun,
        native_cleanup: NativeCleanup::NotObservable,
    }
}

pub fn recover<F: Future<Output = DiscoveryResult>>(future: F, budget: Duration) -> Recovery {
    let (_, outcome, _, harness) = drive(future, false, budget);
    Recovery::Observed { outcome, harness }
}

impl ProbeReport {
    pub fn must_stop(&self) -> bool {
        self.harness == HarnessResult::HostWaitBudgetExceeded
            || self.public_outcome.must_stop()
            || matches!(
                self.recovery,
                Recovery::Observed {
                    harness: HarnessResult::HostWaitBudgetExceeded,
                    ..
                }
            )
            || matches!(self.recovery, Recovery::Observed { outcome, .. } if outcome.must_stop())
    }

    pub fn render(&self) -> String {
        let cleanup = match self.native_cleanup {
            NativeCleanup::NotObservable => "NotObservable",
        };
        let kind = match self.kind {
            ProbeKind::DropAfterPending => "DropAfterPending",
            ProbeKind::ShortDeadline => "ShortDeadline",
        };
        let first = match self.first_poll {
            FirstPoll::Pending => "Pending",
            FirstPoll::Ready => "Ready",
        };
        let stimulus = match self.stimulus {
            Stimulus::ActualOwnerDropped => "ActualOwnerDropped",
            Stimulus::ContinuedPolling => "ContinuedPolling",
            Stimulus::NotApplied => "NotApplied",
        };
        let harness = harness_text(self.harness);
        let timeout = self.public_outcome == PublicOutcome::Error(ErrorCode::Timeout);
        let recovery = match self.recovery {
            Recovery::NotRun => "NotRun".into(),
            Recovery::Observed { outcome, harness } => format!(
                "{} recovery_harness={}",
                outcome.text(),
                harness_text(harness)
            ),
        };
        format!("probe={kind} first_poll={first} public_outcome={} observed_timeout={timeout} stimulus={stimulus} harness={harness} pending_path_covered={} recovery={recovery} timeout_origin=NotObservable native_cancel={cleanup} native_ack={cleanup} native_close={cleanup} os_cleanup={cleanup}", self.public_outcome.text(), self.pending_path_covered)
    }
}

fn harness_text(value: HarnessResult) -> &'static str {
    match value {
        HarnessResult::Completed => "Completed",
        HarnessResult::HostWaitBudgetExceeded => "HostWaitBudgetExceeded",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicBool, Ordering};

    struct PendingOwner(Arc<AtomicBool>);
    impl Future for PendingOwner {
        type Output = DiscoveryResult;
        fn poll(self: std::pin::Pin<&mut Self>, _: &mut Context<'_>) -> Poll<Self::Output> {
            Poll::Pending
        }
    }
    impl Drop for PendingOwner {
        fn drop(&mut self) {
            self.0.store(true, Ordering::SeqCst);
        }
    }

    #[test]
    fn actual_owner_is_dropped_before_recovery() {
        let dropped = Arc::new(AtomicBool::new(false));
        let mut report = probe(
            ProbeKind::DropAfterPending,
            PendingOwner(dropped.clone()),
            Duration::from_secs(1),
        );
        report.recovery = recover(
            std::future::poll_fn(|_| {
                assert!(dropped.load(Ordering::SeqCst));
                Poll::Ready(Ok(DiscoveryOutcome::Services(Vec::new())))
            }),
            Duration::from_secs(1),
        );
        assert!(report.pending_path_covered);
        assert_eq!(report.stimulus, Stimulus::ActualOwnerDropped);
        assert_eq!(
            report.recovery,
            Recovery::Observed {
                outcome: PublicOutcome::Services(0),
                harness: HarnessResult::Completed
            }
        );
    }

    #[test]
    fn first_ready_timeout_is_preserved_without_pending_coverage() {
        let report = probe(
            ProbeKind::ShortDeadline,
            std::future::ready(Err(ErrorCode::Timeout)),
            Duration::from_secs(1),
        );
        assert_eq!(report.first_poll, FirstPoll::Ready);
        assert!(!report.pending_path_covered);
        assert_eq!(
            report.public_outcome,
            PublicOutcome::Error(ErrorCode::Timeout)
        );
        assert!(report.render().contains("observed_timeout=true"));
    }

    #[test]
    fn early_services_never_claim_either_pending_gate() {
        for kind in [ProbeKind::DropAfterPending, ProbeKind::ShortDeadline] {
            let report = probe(
                kind,
                std::future::ready(Ok(DiscoveryOutcome::Services(Vec::new()))),
                Duration::from_secs(1),
            );
            assert_eq!(report.public_outcome, PublicOutcome::Services(0));
            assert_eq!(report.stimulus, Stimulus::NotApplied);
            assert!(!report.pending_path_covered);
        }
    }

    #[test]
    fn pending_timeout_covers_public_path_without_identifying_origin() {
        let mut first = true;
        let report = probe(
            ProbeKind::ShortDeadline,
            std::future::poll_fn(|_| {
                if std::mem::take(&mut first) {
                    Poll::Pending
                } else {
                    Poll::Ready(Err(ErrorCode::Timeout))
                }
            }),
            Duration::from_secs(1),
        );
        assert!(report.pending_path_covered);
        assert_eq!(
            report.public_outcome,
            PublicOutcome::Error(ErrorCode::Timeout)
        );
        assert!(report.render().contains("timeout_origin=NotObservable"));
    }

    #[test]
    fn host_guard_keeps_observed_timeout_but_does_not_cover_gate() {
        let report = probe(
            ProbeKind::ShortDeadline,
            std::future::ready(Err(ErrorCode::Timeout)),
            Duration::ZERO,
        );
        assert_eq!(report.harness, HarnessResult::HostWaitBudgetExceeded);
        assert_eq!(
            report.public_outcome,
            PublicOutcome::Error(ErrorCode::Timeout)
        );
        assert!(!report.pending_path_covered);
        assert!(report.must_stop());
    }

    #[test]
    fn native_normalized_denial_and_disconnect_stop_plan() {
        for code in [ErrorCode::AccessDenied, ErrorCode::Disconnected] {
            let report = probe(
                ProbeKind::DropAfterPending,
                std::future::ready(Err(code)),
                Duration::from_secs(1),
            );
            assert!(report.must_stop());
            assert_eq!(report.recovery, Recovery::NotRun);
        }
    }
}
