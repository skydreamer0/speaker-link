use speakerlink_core::ErrorCode;
use speakerlink_windows::winrt::WindowsDiscovery;
use speakerlink_windows::{CacheMode, DiscoveryRequest, NoWriteDiscovery};
use std::io::Read;
use std::time::{Duration, Instant};
use windows::Devices::Bluetooth::BluetoothDevice;
use windows::Devices::Enumeration::DeviceAccessStatus;
use windows::Win32::System::WinRT::{RoInitialize, RoUninitialize, RO_INIT_MULTITHREADED};
use windows_future::{AsyncStatus, IAsyncOperation};

const BUDGET: Duration = Duration::from_secs(15);
const TICK: Duration = Duration::from_millis(10);

struct Failure {
    stage: &'static str,
    code: ErrorCode,
    hresult: Option<u32>,
}

impl Failure {
    fn normalized(stage: &'static str, code: ErrorCode) -> Self {
        Self {
            stage,
            code,
            hresult: None,
        }
    }

    fn windows(stage: &'static str, error: windows::core::Error) -> Self {
        let raw = error.code().0 as u32;
        let code = match raw {
            0x8007_0005 => ErrorCode::AccessDenied,
            0x8007_048f | 0x8007_0490 => ErrorCode::Disconnected,
            0x8007_05b4 | 0x8007_0102 => ErrorCode::Timeout,
            0x8000_4001 | 0x8000_4002 | 0x8004_0154 => ErrorCode::Unsupported,
            _ => ErrorCode::InternalError,
        };
        Self {
            stage,
            code,
            hresult: Some(raw),
        }
    }
}

struct Apartment;

impl Apartment {
    fn initialize() -> Result<Self, Failure> {
        // This executable owns its main thread and balances successful initialization.
        unsafe { RoInitialize(RO_INIT_MULTITHREADED) }
            .map_err(|error| Failure::windows("com_init", error))?;
        Ok(Self)
    }
}

impl Drop for Apartment {
    fn drop(&mut self) {
        unsafe { RoUninitialize() };
    }
}

struct Acquisition(IAsyncOperation<BluetoothDevice>);

impl Drop for Acquisition {
    fn drop(&mut self) {
        if matches!(self.0.Status(), Ok(status) if status == AsyncStatus::Started) {
            let _ = self.0.Cancel();
        }
        if matches!(self.0.Status(), Ok(status) if status != AsyncStatus::Started) {
            let _ = self.0.Close();
        }
    }
}

struct OwnedDevice(BluetoothDevice);

impl Drop for OwnedDevice {
    fn drop(&mut self) {
        let _ = self.0.Close();
    }
}

fn parse_address(input: &str) -> Result<u64, Failure> {
    let input = input.trim_end_matches(['\r', '\n']);
    if input.len() != 12 || !input.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err(Failure::normalized("input", ErrorCode::InvalidArgument));
    }
    let value = u64::from_str_radix(input, 16)
        .map_err(|_| Failure::normalized("input", ErrorCode::InvalidArgument))?;
    if value == 0 || value == 0xffff_ffff_ffff {
        return Err(Failure::normalized("input", ErrorCode::InvalidArgument));
    }
    Ok(value)
}

fn acquire(address: u64) -> Result<OwnedDevice, Failure> {
    let deadline = Instant::now() + BUDGET;
    let operation = Acquisition(
        BluetoothDevice::FromBluetoothAddressAsync(address)
            .map_err(|error| Failure::windows("acquire_start", error))?,
    );
    loop {
        if Instant::now() >= deadline {
            return Err(Failure::normalized("acquire", ErrorCode::Timeout));
        }
        let status = operation
            .0
            .Status()
            .map_err(|error| Failure::windows("acquire_status", error))?;
        if status == AsyncStatus::Started {
            std::thread::sleep(TICK.min(deadline.saturating_duration_since(Instant::now())));
            continue;
        }
        if status == AsyncStatus::Canceled {
            return Err(Failure::normalized(
                "acquire_cancelled",
                ErrorCode::Indeterminate,
            ));
        }
        let device = OwnedDevice(
            operation
                .0
                .GetResults()
                .map_err(|error| Failure::windows("acquire_result", error))?,
        );
        if Instant::now() >= deadline {
            return Err(Failure::normalized("acquire", ErrorCode::Timeout));
        }
        return Ok(device);
    }
}

fn verify_target(device: &BluetoothDevice, expected_name: &str) -> Result<(), Failure> {
    let name = device
        .Name()
        .map_err(|error| Failure::windows("verify_name", error))?;
    if name != expected_name {
        return Err(Failure::normalized(
            "verify_name",
            ErrorCode::InvalidArgument,
        ));
    }
    let paired = device
        .DeviceInformation()
        .and_then(|info| info.Pairing())
        .and_then(|pairing| pairing.IsPaired())
        .map_err(|error| Failure::windows("verify_pairing", error))?;
    if !paired {
        return Err(Failure::normalized(
            "verify_pairing",
            ErrorCode::AccessDenied,
        ));
    }
    let access = device
        .DeviceAccessInformation()
        .and_then(|info| info.CurrentStatus())
        .map_err(|error| Failure::windows("verify_access", error))?;
    if access != DeviceAccessStatus::Allowed {
        return Err(Failure::normalized(
            "verify_access",
            ErrorCode::AccessDenied,
        ));
    }
    Ok(())
}

mod probes;

struct SelectedTarget {
    address: u64,
    expected_name: String,
}

fn parse_selection(input: &str) -> Result<SelectedTarget, Failure> {
    let mut lines = input.lines();
    let address = parse_address(lines.next().unwrap_or_default())?;
    let expected_name = lines.next().unwrap_or_default();
    if expected_name.is_empty()
        || expected_name.chars().count() > 128
        || expected_name.chars().any(char::is_control)
        || lines.next().is_some()
    {
        return Err(Failure::normalized("input", ErrorCode::InvalidArgument));
    }
    Ok(SelectedTarget {
        address,
        expected_name: expected_name.into(),
    })
}

fn request(timeout: Duration) -> Result<DiscoveryRequest, Failure> {
    let mut request =
        DiscoveryRequest::new(timeout, 64).map_err(|code| Failure::normalized("request", code))?;
    request.cache_mode = CacheMode::Uncached;
    Ok(request)
}

fn run() -> Result<(), Failure> {
    let mut input = String::new();
    std::io::stdin()
        .take(1025)
        .read_to_string(&mut input)
        .map_err(|_| Failure::normalized("input", ErrorCode::InvalidArgument))?;
    if input.len() > 1024 {
        return Err(Failure::normalized("input", ErrorCode::InvalidArgument));
    }
    let selected = parse_selection(&input)?;
    drop(input);
    let _apartment = Apartment::initialize()?;
    let device = acquire(selected.address)?;
    verify_target(&device.0, &selected.expected_name)?;
    drop(selected);
    let mut discovery = WindowsDiscovery::from_authorized_device(device.0.clone())
        .map_err(|code| Failure::normalized("discovery_init", code))?;
    println!("stage=target_verified paired=true exact_name=true query_limit=4 true_denial=NotRun true_unavailable=NotRun");
    let plan = [
        (probes::ProbeKind::DropAfterPending, BUDGET, BUDGET),
        (
            probes::ProbeKind::ShortDeadline,
            Duration::from_millis(1),
            Duration::from_millis(250),
        ),
    ];
    let mut coverage = [false; 2];
    for (index, (kind, timeout, outer)) in plan.into_iter().enumerate() {
        let mut report = probes::probe(kind, discovery.discover(request(timeout)?), outer);
        if !report.must_stop() {
            report.recovery = probes::recover(discovery.discover(request(BUDGET)?), BUDGET);
        }
        println!("{}", report.render());
        coverage[index] = report.pending_path_covered;
        if report.must_stop() {
            if index == 0 {
                println!("probe=ShortDeadline result=NotRun reason=PriorStop");
            }
            println!("suite=Stopped native_cleanup=NotObservable cooperative_cleanup=Unconfirmed");
            return Ok(());
        }
    }
    println!("suite=HarnessCompleted pending_drop_covered={} pending_to_timeout_covered={} native_cleanup=NotObservable timeout_origin=NotObservable", coverage[0], coverage[1]);
    drop(discovery);
    drop(device);
    Ok(())
}

fn main() {
    if let Err(failure) = run() {
        match failure.hresult {
            Some(raw) => eprintln!(
                "stage={} result={} hresult=0x{raw:08x}",
                failure.stage,
                failure.code.as_str()
            ),
            None => eprintln!("stage={} result={}", failure.stage, failure.code.as_str()),
        }
        std::process::exit(failure.code.cli_exit_code().into());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exact_two_lines_accept_generic_name_without_trimming() {
        let selected = parse_selection("123456789abc\r\nLocal Speaker 私人\r\n")
            .ok()
            .unwrap();
        assert_eq!(selected.address, 0x123456789abc);
        assert_eq!(selected.expected_name, "Local Speaker 私人");
        assert_eq!(
            parse_selection("123456789abc\n A \n")
                .ok()
                .unwrap()
                .expected_name,
            " A "
        );
    }

    #[test]
    fn selection_rejects_missing_extra_and_control_input() {
        for value in [
            "",
            "123456789abc",
            "123456789abc\n",
            "123456789abc\n\n",
            "123456789abc\nName\nExtra",
            "123456789abc\nName\n\n",
            "123456789abc\nName\t",
            "000000000000\nName",
            "12:34:56:78:9a:bc\nName",
        ] {
            assert!(parse_selection(value).is_err());
        }
        assert!(parse_selection(&format!("123456789abc\n{}", "字".repeat(128))).is_ok());
        assert!(parse_selection(&format!("123456789abc\n{}", "字".repeat(129))).is_err());
    }

    #[test]
    fn private_fixture_strings_do_not_enter_public_report() {
        use speakerlink_core::model::DeviceRef;
        use speakerlink_windows::{DiscoveredService, DiscoveryOutcome};
        let outcome = DiscoveryOutcome::Services(vec![DiscoveredService {
            device_ref: DeviceRef::new("private-device-id").unwrap(),
            service_uuid: [0; 16],
            connection_host: DeviceRef::new("private-host-address").unwrap(),
            connection_service_name: DeviceRef::new("private-service-name").unwrap(),
            cache_mode: CacheMode::Uncached,
        }]);
        let selected = parse_selection("123456789abc\nprivate-selected-name")
            .ok()
            .unwrap();
        let report = probes::probe(
            probes::ProbeKind::ShortDeadline,
            std::future::ready(Ok(outcome)),
            Duration::from_secs(1),
        )
        .render();
        assert!(report.contains("public_outcome=Services count=1"));
        for private in [
            "private-device-id",
            "private-host-address",
            "private-service-name",
            selected.expected_name.as_str(),
            "123456789abc",
        ] {
            assert!(!report.contains(private));
        }
        assert!(report.contains("native_close=NotObservable"));
    }
}
