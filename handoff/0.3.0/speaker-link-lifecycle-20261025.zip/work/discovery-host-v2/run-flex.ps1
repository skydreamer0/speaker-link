$ErrorActionPreference = 'Stop'
$executable = Join-Path $PSScriptRoot 'target/debug/speakerlink-local-discovery-host-v2.exe'
if (-not (Test-Path -LiteralPath $executable)) { throw 'Reviewed host binary is missing' }
try {
    $devices = @(Get-PnpDevice -Class Bluetooth -PresentOnly -ErrorAction Stop |
        Where-Object { $_.FriendlyName -ceq 'Bose Flex SoundLink' })
} catch {
    Write-Output 'stage=selection result=InventoryUnavailable'
    exit 3
}
$addresses = @($devices | ForEach-Object {
    $match = [regex]::Match($_.InstanceId, '(?i)^BTHENUM\\DEV_([A-F0-9]{12})\\')
    if ($match.Success) { $match.Groups[1].Value.ToUpperInvariant() }
} | Sort-Object -Unique)
if ($addresses.Count -ne 1) {
    Write-Output ('stage=selection result=NoUniqueTarget matches=' + $addresses.Count)
    exit 3
}
$startInfo = [Diagnostics.ProcessStartInfo]::new()
$startInfo.FileName = $executable
$startInfo.UseShellExecute = $false
$startInfo.CreateNoWindow = $true
$startInfo.RedirectStandardInput = $true
$startInfo.RedirectStandardOutput = $true
$startInfo.RedirectStandardError = $true
$startInfo.StandardInputEncoding = [Text.UTF8Encoding]::new($false)
$process = [Diagnostics.Process]::new()
$process.StartInfo = $startInfo
try {
    if (-not $process.Start()) { throw 'Host process could not start' }
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    $process.StandardInput.WriteLine($addresses[0])
    $process.StandardInput.WriteLine('Bose Flex SoundLink')
    $process.StandardInput.Close()
    $addresses = $null
    $devices = $null
    if (-not $process.WaitForExit(55000)) {
        $process.Kill($true)
        $process.WaitForExit()
        Write-Output 'stage=process result=HostProcessBudgetExceeded cooperative_cleanup_unconfirmed=true'
        exit 6
    }
    Write-Output $stdout.GetAwaiter().GetResult()
    Write-Output $stderr.GetAwaiter().GetResult()
    Write-Output ('host_exit=' + $process.ExitCode)
    exit $process.ExitCode
} finally {
    $process.Dispose()
}
