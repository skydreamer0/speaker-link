# Third-party sources and provenance

Original project documents and Rust modules use the project MIT license. The experimental Windows adapter depends on the registry packages listed below. No firmware, binary, logo, packet capture or Bose protocol implementation is bundled.

| Reference | Use so far | Adoption rule |
| --- | --- | --- |
| [aaronsb/bosectl](https://github.com/aaronsb/bosectl) | Protocol/project research; MIT repository | Verify exact files/version and retain copyright and license if reused |
| [bose-connect Rust docs](https://docs.rs/bose-connect/latest/bose_connect/) | API research | Audit exact crate source, license and transitive dependencies before use |
| [BoseConnect-Linux_based-connect](https://github.com/bosefirmware/BoseConnect-Linux_based-connect) | Historical GPL project reference | No copied, translated or linked code in this MIT-only distribution without a separate licensing decision |
| Microsoft Windows API documentation | API design reference | Review selected windows crate version and license before dependency adoption |
| egui/eframe | Proposed native UI | Review chosen release and transitive licenses before adoption |

For every adopted dependency or source fragment, record version/commit, upstream URL, SPDX expression, files used, modifications and notice obligations. A permissive top-level license does not settle every bundled file or transitive dependency. This table is a research inventory, not a completed dependency audit.

## P0 read-only adapter dependencies

The exact 15-package closure, sources, versions, SPDX expressions and upstream Rust minima are in [DEPENDENCIES](docs/DEPENDENCIES.md); Cargo.lock pins registry checksums. All dependencies are unmodified. No third-party Rust source is copied into project modules, and no GPL code is copied, translated or linked. No UI dependency is adopted yet.

- Microsoft windows-rs packages: MIT OR Apache-2.0, MIT option selected. Copyright (c) Microsoft Corporation. Retained [Microsoft MIT notice](licenses/MICROSOFT-MIT.txt), from the upstream repository's license-mit.
- proc-macro2 1.0.101: MIT OR Apache-2.0, MIT option selected. Retained [upstream notice](licenses/PROC-MACRO2-MIT.txt), unmodified.
- quote 1.0.40: MIT OR Apache-2.0, MIT option selected. Retained [upstream notice](licenses/QUOTE-MIT.txt), unmodified.
- syn 2.0.106: MIT OR Apache-2.0, MIT option selected. Retained [upstream notice](licenses/SYN-MIT.txt), unmodified.
- unicode-ident 1.0.19: (MIT OR Apache-2.0) AND Unicode-3.0. MIT option selected and the additional Unicode license retained: [MIT notice](licenses/UNICODE-IDENT-MIT.txt), [Unicode-3.0 notice](licenses/UNICODE-3.0.txt). The latter includes its Unicode copyright attribution and must not be dropped from distribution.

Notice files preserve upstream text rather than inventing copyright statements absent from those files. The project MIT license does not replace any dependency's obligations. Before distributing compiled artifacts, include these notices and review the actual final dependency closure again.

CI references [actions/checkout](https://github.com/actions/checkout/tree/11d5960a326750d5838078e36cf38b85af677262), pinned to commit `11d5960a326750d5838078e36cf38b85af677262` (v4 tag checked when introduced), under [MIT](https://github.com/actions/checkout/blob/11d5960a326750d5838078e36cf38b85af677262/LICENSE). It is used unmodified as CI tooling; no action source is copied into this distribution. Its upstream copyright and license remain with that tooling. CI uses the runner's preinstalled Rust stable toolchain and records its version; this is not a release toolchain pin or a supported-version declaration.
